# Leetcode-Marathon-Pratice

This repo is created to store all the leetcode questions I have practiced up to this point of time for both Algorithm and Database. It is updated regularly. 
