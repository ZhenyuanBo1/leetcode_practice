class Solution {
    public int shortestWordDistance(String[] wordsDict, String word1, String word2) {

    }
}