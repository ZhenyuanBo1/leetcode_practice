class Solution {
    public int countQuadruplets(int[] nums) {

    }
}