class Solution {
    public int arrayNesting(int[] nums) {
    }
}