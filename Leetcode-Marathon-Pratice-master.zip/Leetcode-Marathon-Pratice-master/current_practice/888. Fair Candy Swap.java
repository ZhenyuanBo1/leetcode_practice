class Solution {
    public int[] fairCandySwap(int[] aliceSizes, int[] bobSizes) {

    }
}