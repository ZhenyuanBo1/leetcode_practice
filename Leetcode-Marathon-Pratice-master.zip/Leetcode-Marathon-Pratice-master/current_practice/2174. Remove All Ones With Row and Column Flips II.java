class Solution {
    public int removeOnes(int[][] grid) {

    }
}