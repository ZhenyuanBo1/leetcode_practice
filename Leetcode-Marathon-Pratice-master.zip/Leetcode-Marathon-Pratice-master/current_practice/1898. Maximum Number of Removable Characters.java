class Solution {
    public int maximumRemovals(String s, String p, int[] removable) {

    }
}