class Solution {
    public List<String> ipToCIDR(String ip, int n) {
        
    }
}