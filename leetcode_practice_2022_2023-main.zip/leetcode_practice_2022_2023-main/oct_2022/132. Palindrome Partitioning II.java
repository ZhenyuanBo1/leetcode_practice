class Solution {
    public int minCut(String s) {
    }
}