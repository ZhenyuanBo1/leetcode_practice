class Solution {
    //TO DO
    public int[] findDiagonalOrder(int[][] mat) {
        int rCount = mat.length;
        int cCount = mat[0].length;
        int[] res = new int[rCount * cCount];


    }
}