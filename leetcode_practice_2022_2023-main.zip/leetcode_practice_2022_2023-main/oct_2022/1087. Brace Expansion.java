class Solution {
    public String[] expand(String s) {
        /*
        Input: s = "{a,b}c{d,e}f"
        Output: ["acdf","acef","bcdf","bcef"]
        */
        [a,b]c[d,e]f 
        [ac bc] [df ef]
    }
}