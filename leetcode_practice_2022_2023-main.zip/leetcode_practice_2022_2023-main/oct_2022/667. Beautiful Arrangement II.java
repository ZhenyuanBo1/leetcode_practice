class Solution {
    public int[] constructArray(int n, int k) {
        
    }
}