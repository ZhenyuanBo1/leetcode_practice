class Solution {
    public int longestSubstring(String s, int k) {
    }
}