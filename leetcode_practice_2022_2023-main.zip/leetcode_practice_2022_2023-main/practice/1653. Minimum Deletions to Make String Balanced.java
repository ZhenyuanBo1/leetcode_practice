class Solution {
    public int minimumDeletions(String s) {

    }
}