class Solution {
    public int maxFrequency(int[] nums, int k) {
    }
}