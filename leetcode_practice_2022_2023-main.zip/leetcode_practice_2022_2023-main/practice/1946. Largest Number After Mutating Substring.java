class Solution {
    public String maximumNumber(String num, int[] change) {

    }
}