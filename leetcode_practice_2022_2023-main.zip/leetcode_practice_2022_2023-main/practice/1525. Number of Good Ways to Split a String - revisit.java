class Solution {
    public int numSplits(String s) {

    }

}