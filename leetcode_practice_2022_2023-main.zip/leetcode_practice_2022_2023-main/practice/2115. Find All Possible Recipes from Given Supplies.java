class Solution {
    //TO DO: TOPOLOGICAL SORT
    public List<String> findAllRecipes(String[] recipes, List<List<String>> ingredients, String[] supplies) {

    }
}
