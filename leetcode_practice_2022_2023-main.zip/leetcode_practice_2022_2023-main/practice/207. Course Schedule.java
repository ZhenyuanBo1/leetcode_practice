class Solution {
    public boolean canFinish(int numCourses, int[][] prerequisites) {
    }
}