class Solution {
    public int rob(int[] nums) {
        
    }
}