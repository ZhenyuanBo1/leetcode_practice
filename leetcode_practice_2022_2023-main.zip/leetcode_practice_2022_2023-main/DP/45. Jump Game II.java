class Solution {
    public int jump(int[] nums) {

    }
}