class Solution {
    public int maximumInvitations(int[][] grid) {
        
    }
}