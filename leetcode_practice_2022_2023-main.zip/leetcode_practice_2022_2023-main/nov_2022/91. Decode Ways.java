class Solution {
    public int numDecodings(String s) {
        //thinking if we can use backtrack
    }
}