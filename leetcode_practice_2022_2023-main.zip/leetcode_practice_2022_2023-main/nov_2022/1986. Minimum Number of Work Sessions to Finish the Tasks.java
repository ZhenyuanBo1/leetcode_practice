class Solution {
    //TO DO
    public int minSessions(int[] tasks, int sessionTime) {
    }
}