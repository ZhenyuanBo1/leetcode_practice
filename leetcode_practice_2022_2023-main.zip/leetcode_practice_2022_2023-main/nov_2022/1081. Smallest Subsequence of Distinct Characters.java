class Solution {
    public String smallestSubsequence(String s) {
    }
}