class Solution {

    public int maxCompatibilitySum(int[][] students, int[][] mentors) {

    }
}